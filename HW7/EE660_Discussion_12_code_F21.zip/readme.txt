qns3vm.zip
	original code of QNS3VM
	credit to:
	http://www.fabiangieseke.de/index.php/code/qns3vm
examples.py
	file in qns3vm.zip, modified to work in Python3
qns3vm.py
	file in qns3vm.zip, modified to work in Python3
wrapper.py
	example of sklearn compatible wrapper of QNS3VM
	credit to:
	https://github.com/tmadl/semisup-learn/blob/master/methods/scikitTSVM.py

cotrain_classifiers.py
cotrain_examples.py
	example code for co-training
	credit to:
	https://github.com/tmadl/semisup-learn/blob/master/methods/scikitTSVM.py

EE660_Discussion_12_code_F21.ipynb
	visualization of an example in QNS3VM
	credit to EE660